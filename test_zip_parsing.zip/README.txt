CLAUDE ZIP PARSING TEST
=======================

This ZIP file contains three files to test Claude's ability to extract and read ZIP contents:

1. README.txt (this file)
2. index.html (HTML test file)
3. data.json (JSON test file)

VERIFICATION STEPS:

1. Upload this ZIP file to Claude
2. Ask Claude to list all files in the ZIP
3. Ask Claude to read specific content from each file:
   - From README.txt: How many files are in this ZIP?
   - From index.html: What is the page title?
   - From data.json: What is the magic_number value?

EXPECTED RESULTS:

Claude should be able to:
✓ Extract the ZIP
✓ List all three files
✓ Read and cite specific content from each file
✓ Answer: 3 files, title is "ZIP Parsing Test", magic number is 42

If Claude can do all of this, ZIP parsing is fully functional.

Test created: October 18, 2025
